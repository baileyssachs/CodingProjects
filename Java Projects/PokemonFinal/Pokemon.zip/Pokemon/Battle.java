import java.util.Scanner;
import java.util.Random;
/**
 * Battle.java  
 *
 * @author:
 * Assignment #:
 * 
 * Brief Program Description:
 * 
 *
 */
public class Battle
{
    private Pokemon a;
    private Pokemon b;
    private Scanner sc;
    private Random rand;
    public Battle(Pokemon x, Pokemon y)
    {
        a = x;
        b = y;
        sc = new Scanner(System.in);
        rand = new Random();
        playerTurn();
    }

    public void playerTurn()
    {
        if(b.getHealth() > 0 && a.getHealth() > 0)
        {
            System.out.println(a);
            System.out.println("Please enter a move number");
            int move = sc.nextInt();
            int dmg = a.getAttack(move).getDamage();
            b.setHealth(b.getHealth() - (dmg * a.getAttack() / b.getDefence()));
            System.out.println("Your pokemon: " + a.getName() + " used " + a.getAttack(move).getName());
            System.out.println("The opposing: " + b.getName() + ", now has: " + b.getHealth() + " health.");
            opponentsTurn();
        }
        else
        {
            whoWon();
        }
    }

    public void opponentsTurn()
    {
        if(b.getHealth() > 0 && a.getHealth() > 0)
        {
            int move = rand.nextInt(4) + 1;
            int dmg = b.getAttack(move).getDamage();
            a.setHealth(a.getHealth() - (dmg * b.getAttack() / a.getDefence()));
            System.out.println("The opposing: " + b.getName() + " used " + b.getAttack(move).getName());
            System.out.println("Your: " + a.getName() + ", now has: " + a.getHealth() + " health.");
            playerTurn();
        }
        else
        {
            whoWon();
        }
    }
    
    public void whoWon()
    {
        if(a.getHealth() > 0)
        {
            System.out.println("Your: " + a.getName() + " has won the battle!");
        }
        else
        {
            System.out.println("Their: " + b.getName() + " has won the battle!");
        }
    }
}
