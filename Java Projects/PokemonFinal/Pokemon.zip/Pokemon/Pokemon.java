
/**
 * Pokemon.java  
 *
 * @author:
 * Assignment #:
 * 
 * Brief Program Description:
 * 
 *
 */
public class Pokemon
{
    //1 is fire, 2 is water, 3 is grass. Strings are abnoxious
    private String name;
    private int type;
    private int level;
    private int exp;
    private int health;
    private int attack;
    private int defence; 
    private int spAttack;
    private int spDefence;
    private int speed;

    private Attack a1;
    private Attack a2;
    private Attack a3;
    private Attack a4;
    public Pokemon(String n, int t, int l, int h,int a,int d,int sa,int sd,int sp, Attack w, Attack x, Attack y, Attack z)
    {
        name = n;
        health = h;
        attack = a;
        level = l;
        exp = level * 10;
        type = t;
        defence = d; 
        spAttack = sa;
        spDefence = sd;
        speed = sp;
        a1 = w;
        a2 = x;
        a3 = y;
        a4 = z;
    }

    public String getName()
    {
        return name;
    }

    public int getHealth()
    {
        return health;
    }

    public void setHealth(int h)
    {
        health = h;
    }

    public int getAttack()
    {
        return attack;
    }

    public void setAttack(int a)
    {
        attack = a;
    }

    public int getDefence(){
        return defence;
    }

    public void setDefence(int d)
    {
        defence = d;
    }

    public int getSPAttack()
    {
        return spAttack;
    }

    public void setSPAttack(int s)
    {
        spAttack = s;
    }

    public int getSPDefence()
    {
        return spDefence;
    }

    public void setSPDefence(int d)
    {
        spDefence = d;
    }

    public int getSpeed()
    {
        return speed;
    }

    public void setSpeed(int s)
    {
        speed = s;
    }

    /**
     * Calculates the attack
     * @param int Which attack is being used
     * @param String The oponent's type
     * @param int The oponent's defence
     * @param int The oponent's special defence
     * @returns int The amount of damage dealt
     */
    public int getAttack(int i, int opType, int def, int spDef)
    {
        Attack temp = new Attack(null, 0,0,0);
        double mod = 1;

        if(i == 1){
            temp =  a1;
        }
        else if(i == 2){
            temp = a2;
        }
        else if(i == 3){
            temp = a3;
        }
        else if(i == 4){
            temp = a4;
        }

        if(temp.getType() == 2 && opType == 1)
        {
            mod = 2;
        }

        else if(temp.getType() == 3 && opType == 2)
        {
            mod = 2;
        }
        else if(temp.getType() == 1 && opType == 3)
        {
            mod = 2;
        }

        else if(temp.getType() == 1 && opType == 2)
        {
            mod = .5;
        }
        else if(temp.getType() == 2 && opType == 3)
        {
            mod = .5;
        }
        else if(temp.getType() == 3 && opType == 1)
        {
            mod = .5;
        }
        mod *= 1 - (((int)(Math.random() + 25))/100);

        if(temp.getTypeOfAttack() == 1)
        {
            return (int)(((((((2 * level)/5)+2) * temp.getDamage() * attack/def)/50)+2)*mod);
        }
        else
        {
             return (int)(((((((2 * level)/5)+2) * temp.getDamage() * spAttack/spDef)/50)+2)*mod);
        }
    }

    public String toString()
    {
        return "Pokemon: " + name + ", Health: " + health + ", Attack 1: " + a1.getName() + ", Attack 2: " + a2.getName() + ", Attack 3: " + a3.getName() + ", Attack 4: " + a4.getName();
    }
}
