
/**
 * Attack.java  
 *
 * @author:
 * Assignment #:
 * 
 * Brief Program Description:
 * 
 *
 */
public class Attack
{
    private String name;
    private int damage;
    private int type;  //Special or physical 1 for Physical 2 for special
    private int typeOfAttack;
    /**
     * types: 1 = Fire, 2 = Water, 3 = Grass, 4 = normal
     */
    public Attack(String n, int d, int t, int tp)
    {
        name = n;
        damage = d; 
        type = t;
        typeOfAttack = tp;
    }
    
    /**
     * returns 1 for Fire, 2 for Water, 3 for Grass, 4 for normal
     */
    public int getType()
    {
        return type;
    }
    
    /**
     * 1 for physical 2 for special
     */
    public int getTypeOfAttack()
    {
        return typeOfAttack;
    }
    
    public int getDamage()
    {
        return damage;
    }
    
    public String getName()
    {
        return name;
    }
}
