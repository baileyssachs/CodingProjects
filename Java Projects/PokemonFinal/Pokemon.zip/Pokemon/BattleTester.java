import java.util.Scanner;
/**
 * Battle.java 
 *
 * @author:
 * Assignment #:
 * 
 * Brief Program Description:
 * 
 *
 */

public class BattleTester 
{
   public static void main(String[] args)
   {
       Scanner sc = new Scanner(System.in);
       Attack w = new Attack("Tackle", 4, 1);
       Attack x = new Attack("scratch", 2, 1);
       Attack y = new Attack("HeadButt", 3, 1);
       Attack z = new Attack("Hit", 4, 1);
       Pokemon a = new Pokemon("Bulbasaur", 10,5,5,3,4,8,w,x,y,z);
       Pokemon b = new Pokemon("Charmander",10,5,5,3,4,8,w,x,y,z);
       Battle start = new Battle(a,b);
   }
}
