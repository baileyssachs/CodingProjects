
/**
 * PokemonTester.java 
 *
 * @author:
 * Assignment #:
 * 
 * Brief Program Description:
 * 
 *
 */

public class PokemonTester 
{
   public static void main(String[] args)
   {
       Attack a1 = new Attack("Scratch", 10, 4, 1);
       Attack a2 = new Attack("Scratch", 10, 4, 1);
       Attack a3 = new Attack("Scratch", 10, 4, 1);
       Attack a4 = new Attack("Scratch", 10, 4, 1);
       Pokemon p1 = new Pokemon("Charmander", 1, 10, 100, 20, 10, 100, 100,100, a1, a2, a3, a4);
       System.out.println(p1.toString());
       //feel free to check my math for this one
       System.out.println("This is how much Charmander (20 atk) using a 10 damage scratch does to a pokemon of type fire, with 10 defence: " +p1.getAttack(1,1,10,10));
   }
}
